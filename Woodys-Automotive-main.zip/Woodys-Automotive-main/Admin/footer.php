<script src="/WoodysAutomotive/assest/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function () {
        $('#example,#example-Bed,#example-Staff-Pation').DataTable();
    });
</script>
</body>
</html>